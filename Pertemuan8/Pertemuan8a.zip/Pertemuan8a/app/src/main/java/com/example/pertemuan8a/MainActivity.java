package com.example.pertemuan8a;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText Text_Angka1, Text_Angka2;
    TextView Hasil_Angka;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Text_Angka1 = findViewById(R.id.Txt_Angka1);
        Text_Angka2 = findViewById(R.id.Txt_Angka2);
        Hasil_Angka = findViewById(R.id.Lbl_Hasil);
    }

    public void Bersihkan_Angka(View v) {
        Text_Angka1.setText(" ");
        Text_Angka2.setText(" ");
        Hasil_Angka.setText(" ");
    }

    public void Tombol_Tambah(View v) {
        if (Text_Angka1.getText().length() > 0 && Text_Angka2.getText().length() > 0) {
            double angka1, angka2, hasil;
            angka1 = Double.parseDouble(Text_Angka1.getText().toString());
            angka2 = Double.parseDouble(Text_Angka2.getText().toString());

            hasil = angka1 + angka2;
            Hasil_Angka.setText("Hasil dari " + angka1 + " + " + angka2 + " = " + hasil);
        } else {
            Toast toast = Toast.makeText(MainActivity.this, "Mohon Masukkan", Toast.LENGTH_SHORT);
            toast.show();
        }

    }

    public void Tombol_Kurang(View v) {
        if (Text_Angka1.getText().length() > 0 && Text_Angka2.getText().length() > 0) {
            double angka1, angka2, hasil;
            angka1 = Double.parseDouble(Text_Angka1.getText().toString());
            angka2 = Double.parseDouble(Text_Angka2.getText().toString());

            hasil = angka1 - angka2;
            Hasil_Angka.setText("Hasil dari " + angka1 + " - " + angka2 + " = " + hasil);
        } else {
            Toast toast = Toast.makeText(MainActivity.this, "Mohon Masukkan", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public void Tombol_Kali(View v) {
        if (Text_Angka1.getText().length() > 0 && Text_Angka2.getText().length() > 0) {
            double angka1, angka2, hasil;
            angka1 = Double.parseDouble(Text_Angka1.getText().toString());
            angka2 = Double.parseDouble(Text_Angka2.getText().toString());

            hasil = angka1 * angka2;
            Hasil_Angka.setText("Hasil dari " + angka1 + " x " + angka2 + " = " + hasil);
        } else {
            Toast toast = Toast.makeText(MainActivity.this, "Mohon Masukkan", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public void Tombol_Bagi(View v) {
        if (Text_Angka1.getText().length() > 0 && Text_Angka2.getText().length() > 0) {
            double angka1, angka2, hasil;
            angka1 = Double.parseDouble(Text_Angka1.getText().toString());
            angka2 = Double.parseDouble(Text_Angka2.getText().toString());

            hasil = angka1 / angka2;
            Hasil_Angka.setText("Hasil dari " + angka1 + " / " + angka2 + " = " + hasil);
        } else {
            Toast toast = Toast.makeText(MainActivity.this, "Mohon Masukkan", Toast.LENGTH_SHORT);
            toast.show();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu1) {
            startActivity(new Intent(this, Menu1.class));
        }
        return true;
    }
}