package com.example.pertemuan8a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Menu1 extends AppCompatActivity {

    EditText Text_Angka;
    TextView Hasil_Angka;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Text_Angka = findViewById(R.id.Txt_Angka);
        Hasil_Angka = findViewById(R.id.Lbl_Hasil2);
    }
    public void Cari_Ganjilgenap(View v) {

        if(Text_Angka.getText().length()>0){
            int a;
            a = Integer.parseInt(Text_Angka.getText().toString());
            if (a % 2 == 1) {
                Hasil_Angka.setText(a + " Adalah Bilangan Ganjil");
            }else{
                Hasil_Angka.setText(a + " Adalah Bilangan Genap");
            }
        }else{
            Toast toast = Toast.makeText(Menu1.this, "Mohon Masukkan", Toast.LENGTH_SHORT);
            toast.show();
        }
    }
}
