package com.example.pertemuan7b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText Text_Nama;
    TextView Hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Text_Nama = findViewById(R.id.Txt_Nama);
        Hasil = findViewById(R.id.Lbl_Hasil);
    }
    public void Tampil_Hasil(View v){
        Hasil.setText("Nama Anda Adalah : "+Text_Nama.getText());
    }

}
