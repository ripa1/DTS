package com.example.pertemuan9a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText Text_Nama,Text_Nim,Text_Kampus;
    TextView Hasil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Text_Nim = findViewById(R.id.Txt_Nim);
        Text_Nama = findViewById(R.id.Txt_Nama);
        Text_Kampus = findViewById(R.id.Txt_Kampus);
        Hasil = findViewById(R.id.Lbl_Ok);
    }
    public void Tampil_Ok (View v){
        Hasil.setText("Hasil : \n Nim : "+Text_Nim.getText()+"\n Nama : "+Text_Nama.getText()+"\n Kampus : "+Text_Kampus.getText());
    }
}
