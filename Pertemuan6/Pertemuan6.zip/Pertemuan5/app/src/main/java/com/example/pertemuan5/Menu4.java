package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Menu4 extends AppCompatActivity {

    EditText Text_Angka;
    TextView Hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu4);

        Text_Angka = findViewById(R.id.Txt_Angka);
        Hasil = findViewById(R.id.Akar_Hasil);

    }

    public void Tampil_Akar(View v){
        String hasil = Text_Angka.getText().toString();
        int akar = Integer.parseInt(hasil);

        int x=1;
        int y=x*x;

        while(y !=akar){
            x++;
            y=x*x;
        }
        Hasil.setText("Akar Adalah : "+x);
    }
}
